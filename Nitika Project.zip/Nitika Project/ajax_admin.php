<?php
session_start();
	$lol="";
	$lol1="";
	$lol2="";
	$lol3="";
	if (empty($_POST["name"])) 
	{
		$lol1="name_empty";
		$lol="invalid";
	} 
	$namee =  $_POST["name"];
	if (!preg_match("/^[a-zA-Z ]*$/",$namee)) 
	{
		$lol2="name_notchar";
		$lol="invalid";
	}
	if (empty($_POST["password"])) 
	{
		$lol3="password_empty";
		$lol="invalid";
	} 

	if($lol=="")
		{
			$name=$_POST["name"];
			$password=$_POST["password"];
			$password= md5($password);
			require_once("dbconstant.php");
			$mysqli = new mysqli(address, user, pass, db);
			$sql = "SELECT name,password from admin WHERE name = '$name' AND  password = '$password' LIMIT 1";
			$result = $mysqli->query($sql);
			if (!$result->num_rows == 1) 
			{
				mysqli_close($mysqli);	
				$lol="wrong_combination";
				echo $lol.$lol1.$lol2.$lol3;
			}
			else
			{
				$run=mysqli_query($mysqli,$sql);
				while($row=mysqli_fetch_array($run))  
				{   
					$name=$row[0];
				}
				$_SESSION['admin']=$name;
				$lol="success";
				echo $lol.$lol1.$lol2.$lol3;
			}
			mysqli_close($mysqli);
		}
		
	if($lol=="invalid")
		{
			echo $lol.$lol1.$lol2.$lol3;
		}
?>