<?php
	const address = 'localhost';
    const user = 'root';
    const pass = '';
    const db = 'my_project';
?>