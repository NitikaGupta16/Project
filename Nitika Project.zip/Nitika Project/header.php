<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#headd" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<div class="navbar-header">
			<div class="logo">Navtech Computer Systems</div>
		</div>
		<div class="collapse navbar-collapse headd" id="headd">
			<ul class="nav navbar-nav navbar-right">
				<li class="nav_items nav_items1"><a href="#">HOME</a></li>
				<li class="nav_items"><a href="#carousel-12">FEATURES</a></li>
				<li class="nav_items"><a href="#contact">CONTACT</a></li> 
				<li class="nav_items"><a href="admin.php">ADMIN</a></li>
			</ul>
		</div>
	</div> 
</nav>

